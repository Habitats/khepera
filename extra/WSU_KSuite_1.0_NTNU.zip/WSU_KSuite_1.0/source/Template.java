import edu.wsu.KheperaSimulator.RobotController;
import edu.wsu.KheperaSimulator.KSGripperStates;


public class Template extends RobotController{


	public Template() 
	{
	}
	

	public void doWork() throws Exception
	{
	}


	public void close() throws Exception
	{
	}
}
