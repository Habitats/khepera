package edu.wsu.KheperaSimulator;

public class KSGripperStates 
{
	public static final int ARM_UP = 20;
	public static final int ARM_DOWN = 21;
	public static final int GRIP_OPEN = 22;
	public static final int GRIP_CLOSED = 23;
}
