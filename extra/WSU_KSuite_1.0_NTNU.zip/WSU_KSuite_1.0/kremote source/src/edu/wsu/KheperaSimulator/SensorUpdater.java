/*
 *		SensorUpdater.java
 *
 *		Created on 08 JAN 2005 by Duane Bolick
 *		ver 1.0
 *
 *		This class sends commands to the Khepera via socket every so often.  
 *		Its purpose is to send commands that make the Khepera tell us its
 *		sensor values (and those messages are received by the Listener object,
 *		of course).  We need to update the distance and light sensor arrays,
 *		the wheel position sensor variables, and the object-present sensor
 *		variable.
 *
 *		All this class does is send the commands that make the Khepera send us
 *		that information back.  All incoming messages are caught and parsed
 *		by the Listener object, and the MessageProcessor object threads it
 *		spawns to deal with each incoming message.  Here are the Khepera
 *		language commands it sends, and what each of those means.
 *
 *
 *		Command String		What that command means to the Khepera
 *
 *		"N"					Send me the distance sensor values
 *		"O"					Send me the light sensor values
 *		"T,1,G"				Send me the object-present sensor value
 *
 *	
 */

package edu.wsu.KheperaSimulator;

import java.io.*;
import java.util.*;

public class SensorUpdater implements Runnable
{
	// String variables that'll contain the Khepera commands
	private String distSensors;
	private String lightSensors;
	private String wheelSensors;
	private String objectSensors;
	
    private PrintWriter writer;
    private CurrentRobotState state;
	private long timeout;
    
    
    public SensorUpdater( long _timeout, PrintWriter _writer, CurrentRobotState _state )
    {
    	timeout = _timeout;
        state = _state;
        writer = _writer;
        
        // The khepera commands
        distSensors = "N";
        lightSensors = "O";
        objectSensors = "T,1,G";
    }


	public void run()
	{
		while( state.sessionStatus == ClientConfiguration.RUNNING )
		{
			write(distSensors);
			write(lightSensors);
			write(objectSensors);
		
		
			try
			{
				Thread.sleep(timeout);
			}
			
			catch(Exception e)
			{
			}
		}
	}
   
   
  	public void write( String m )
   	{
   		if( ClientConfiguration.DEBUG ) System.out.println("updater writes: " + m);
   		
   		writer.println(m);
   		writer.flush();

		try
		{
			Thread.sleep(timeout);
		}

		catch(Exception e)
		{
		}
   	}
     
   
}
