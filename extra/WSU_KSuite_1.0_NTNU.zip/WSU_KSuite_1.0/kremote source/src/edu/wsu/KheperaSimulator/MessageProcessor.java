package edu.wsu.KheperaSimulator;
import java.util.*;
/*
 * MessageProcessor.java
 *
 * Created on July 20, 2001, 2:00 PM
 */


/**
 *
 * @author  steve
 * @version 
 */

/**
 *  This object is created per message recieved from the robot. Because
 * the process of determining which data the message applies to and converting
 * the string to some other type requires significant computation time, threads
 * are spawned -- relieving other reading and handling tasks. 
 */

public class MessageProcessor extends Thread
{
    
    private CurrentRobotState state;
    private Sensor[] sensors;
    private Motor  motors;
    private String message;
    private boolean messageValid;
    
   
    public MessageProcessor(CurrentRobotState _state, String _message)
    {
        state = _state;
        message = new String(_message);
		sensors = new Sensor[8];
        sensors = state.getSensorValues();
	}


    private void processSensorArray()
    {
    	if ( ClientConfiguration.DEBUG ) System.out.println("posted sensor array: " + message);
    	
        int len = message.length();
        char type = message.charAt(0);
        String clip = message.substring(0, len-1);
        StringTokenizer tokens = new StringTokenizer(clip, ",");
        
        int i = 0;
        while(tokens.hasMoreTokens())
		{
            String next = tokens.nextToken();
            if(next.equals("n") || next.equals("o"))
                continue;
            try {
                if(type == 'n')
                    sensors[i].setDistValue(Integer.parseInt(next));
                else
                    sensors[i].setLightValue(Integer.parseInt(next));
            } catch (NumberFormatException e) {
                //System.err.println("String->Int: at []=="+ i);
            }

            i++;
        }
    }
    
    
    private void processObjPresent()
    {
    	if ( ClientConfiguration.DEBUG ) System.out.println("posted object present: " + message);
    	
        int len = message.length();

		if( len < 6 )
			return;

        char temp = message.charAt(6);

        if(temp == '0')
            state.postObjectPresent(false);
        else
            state.postObjectPresent(true);
    }
    
    
    private void processResistivity()
    {
    	if ( ClientConfiguration.DEBUG ) System.out.println("posted resistivity: " + message);
    	
        int len = message.length();
        Integer tempIntVal = new Integer(0);
        
        tempIntVal = Integer.valueOf(message.substring(2,len-1));
        state.postResistivity(tempIntVal.intValue());
    }
    
    
    
    
    
    public void processStatusMessage()
    {
       	if( message.startsWith("#TIMEOUT") )
    	{
    		state.sessionStatus = ClientConfiguration.TIMEOUT;
    	}
    	
    	else if( message.startsWith("#START") )
    	{
    		state.waitTime = "now";
    		state.sessionStatus = ClientConfiguration.RUNNING;
    	}
    	
    	else if( message.startsWith("#WAIT") )
    	{
    		state.waitTime = "in " + message.substring(6);
    		state.sessionStatus = ClientConfiguration.WAITING;
    	}
    	
    	else if( message.startsWith("#STUCK") )
    	{
    		state.waitTime = "must wait until the Khepera is unstuck";
    		state.sessionStatus = ClientConfiguration.STUCK;
    	}
    }
    
    
    public void run() 
    {
    	if ( ClientConfiguration.DEBUG ) System.out.println("processor gets: " + message);
    	
    	if( message.length() < 3 )
    		return;

        switch(message.charAt(0))
        {
        	case '#': processStatusMessage();
        			  break;
            case 'n':
            case 'o': processSensorArray();
                      break;
            case 't': processObjPresent();
                      break;
            case 'f': processResistivity();
                      break;
        }
    }

}
